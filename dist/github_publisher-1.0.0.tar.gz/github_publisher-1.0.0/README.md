# GitHub Publisher

Package and publish OpenSeneca tools to PyPI and GitHub.

## What It Does

The GitHub Publisher automates the release process for OpenSeneca tools:

1. **Validates** the tool has proper packaging structure (setup.py, README.md, etc.)
2. **Builds** Python distributions (wheel + sdist)
3. **Publishes** to PyPI using twine
4. **Pushes** to GitHub repository
5. **Creates** GitHub release with version tag

## Usage

```bash
# Full publish (PyPI + GitHub + release)
python3 main.py content-pipeline

# Skip PyPI, only push to GitHub
python3 main.py content-pipeline --skip-pypi

# Skip GitHub, only publish to PyPI
python3 main.py content-pipeline --skip-github

# Skip release creation
python3 main.py content-pipeline --skip-release
```

## Requirements

### Tool Requirements
The tool being published must have:
- `setup.py` or `pyproject.toml` with package metadata
- `README.md` with usage instructions
- Git repository with remote origin

### System Requirements
- Python 3.8+
- `build` package: `pip install build`
- `twine` package: `pip install twine`
- `gh` CLI (optional, for GitHub releases)
- PyPI credentials (in `~/.pypirc` or environment variables)

## Setup

### PyPI Credentials

Option 1: Using `~/.pypirc`
```bash
cat > ~/.pypirc << 'EOF'
[pypi]
username = __token__
password = pypi-<your-token>
EOF
```

Option 2: Using environment variables
```bash
export TWINE_USERNAME=__token__
export TWINE_PASSWORD=pypi-<your-token>
```

### Install Dependencies
```bash
pip install build twine gh  # gh is optional
```

## Example Workflow

1. **Prepare your tool** for publishing:
   - Ensure `setup.py` or `pyproject.toml` exists
   - Add/Update `README.md`
   - Commit all changes to git

2. **Run the publisher**:
   ```bash
   cd ~/.openclaw/workspace/tools/github-publisher
   python3 main.py your-tool-name
   ```

3. **Install your tool**:
   ```bash
   pip install squad-content-pipeline  # Example
   ```

## Error Handling

The tool will stop on critical errors but continue on non-critical ones:

- **Critical** (stops execution):
  - Tool directory not found
  - Missing `setup.py` or `README.md`
  - Build failure
  - Git push failure

- **Non-critical** (warns and continues):
  - PyPI publish failure (continues to GitHub push)
  - GitHub release creation failure
  - Uncommitted changes (auto-commits)

## Current Projects

Ready to publish:
- ✅ `content-pipeline` - Content Pipeline CLI for Seneca
- ✅ `axon-ingester` - Auto-Ingester for Axon

## Deployment

Local use only. No cron job needed - run manually when ready to publish.

---

*Created by Archimedes (Engineering) on 2026-05-08*
